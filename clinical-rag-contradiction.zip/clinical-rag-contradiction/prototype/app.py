"""
FastAPI prototype: submit a patient_id and a natural-language query, get
back retrieved evidence, a grounded extractive summary, and any detected
contradictions relevant to the retrieved notes.

Run with:
    uvicorn app:app --reload --port 8003
"""

import sys
import json
from pathlib import Path
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

sys.path.append(str(Path(__file__).parent.parent / "src"))
from retrieval import load_retriever
from contradiction_detector import run_on_corpus
from generate import generate_summary

DATA_DIR = Path(__file__).parent.parent / "data"

app = FastAPI(
    title="Clinical RAG + Contradiction Detection API",
    description="Retrieval-augmented clinical note query with rule-based contradiction detection.",
    version="1.0.0",
)

retriever = load_retriever()
with open(DATA_DIR / "clinical_notes.json") as f:
    ALL_NOTES = json.load(f)
ALL_CONTRADICTION_FLAGS = run_on_corpus(ALL_NOTES)

VALID_PATIENT_IDS = sorted(set(n["patient_id"] for n in ALL_NOTES))


class QueryRequest(BaseModel):
    patient_id: str = Field(..., description="e.g. PT0000")
    query: str = Field(..., description="Natural-language question about the patient's notes")
    top_k: int = Field(4, ge=1, le=10)


@app.get("/")
def root():
    return {
        "service": "Clinical RAG + Contradiction Detection API",
        "n_patients": len(VALID_PATIENT_IDS),
        "example_patient_ids": VALID_PATIENT_IDS[:5],
        "docs": "/docs",
    }


@app.post("/query")
def query_patient(req: QueryRequest):
    if req.patient_id not in VALID_PATIENT_IDS:
        raise HTTPException(status_code=404, detail=f"Unknown patient_id. Valid examples: {VALID_PATIENT_IDS[:5]}")

    retrieved = retriever.retrieve(req.query, patient_id=req.patient_id, top_k=req.top_k)
    patient_flags = [f for f in ALL_CONTRADICTION_FLAGS if f["patient_id"] == req.patient_id]
    summary = generate_summary(req.query, retrieved, patient_flags)

    return {
        "patient_id": req.patient_id,
        "query": req.query,
        "retrieved_notes": [
            {
                "note_index": r["note"]["note_index"],
                "note_type": r["note"]["note_type"],
                "score": round(r["score"], 4),
                "text": r["note"]["text"],
            }
            for r in retrieved
        ],
        "contradiction_flags_for_patient": patient_flags,
        "summary": summary,
    }


@app.get("/patients/{patient_id}/contradictions")
def get_patient_contradictions(patient_id: str):
    if patient_id not in VALID_PATIENT_IDS:
        raise HTTPException(status_code=404, detail="Unknown patient_id")
    flags = [f for f in ALL_CONTRADICTION_FLAGS if f["patient_id"] == patient_id]
    return {"patient_id": patient_id, "contradiction_flags": flags}


@app.get("/health")
def health():
    return {"status": "ok"}
