"""
Retrieval layer for the clinical RAG pipeline.

Uses TF-IDF + cosine similarity over per-note chunks, scoped per patient.
This is a deliberate, documented choice: dense neural embeddings (e.g.,
sentence-transformers) would normally be preferred for semantic retrieval,
but downloading pretrained embedding model weights requires access to
external model hubs not available in this project's development
environment. TF-IDF is a legitimate, classic, fully-reproducible retrieval
method with no external dependencies beyond scikit-learn, and the
retrieval interface below is written so a dense-embedding backend could
be substituted without changing any downstream code (see README).
"""

import json
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DATA_DIR = Path("/home/claude/clinical-rag-contradiction/data")


class ClinicalRetriever:
    def __init__(self, notes):
        self.notes = notes
        self.texts = [n["text"] for n in notes]
        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        self.doc_matrix = self.vectorizer.fit_transform(self.texts)

    def retrieve(self, query: str, patient_id: str = None, top_k: int = 5):
        query_vec = self.vectorizer.transform([query])
        sims = cosine_similarity(query_vec, self.doc_matrix)[0]

        candidate_idx = list(range(len(self.notes)))
        if patient_id is not None:
            candidate_idx = [i for i in candidate_idx if self.notes[i]["patient_id"] == patient_id]

        ranked = sorted(candidate_idx, key=lambda i: sims[i], reverse=True)[:top_k]
        results = []
        for i in ranked:
            results.append({
                "note": self.notes[i],
                "score": float(sims[i]),
            })
        return results


def load_retriever():
    with open(DATA_DIR / "clinical_notes.json") as f:
        notes = json.load(f)
    return ClinicalRetriever(notes)


if __name__ == "__main__":
    retriever = load_retriever()

    results = retriever.retrieve("What are the patient's known drug allergies?", patient_id="PT0000", top_k=3)
    print("Query: What are the patient's known drug allergies? (patient PT0000)\n")
    for r in results:
        print(f"[score={r['score']:.3f}] note_index={r['note']['note_index']} ({r['note']['note_type']})")
        print(r["note"]["text"].split("\n")[2])
        print()
