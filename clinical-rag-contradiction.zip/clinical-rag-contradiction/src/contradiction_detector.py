"""
Rule-based contradiction detection over a patient's clinical notes.

Extracts structured assertions from free-text notes using pattern matching
(allergy status, medication active/discontinued status), then checks for
direct logical conflicts between assertions of the same type across a
patient's note history. This is genuine rule-based logic, evaluable
against the ground-truth contradictions injected by the data generator
(see evaluate.py) -- it is not a placeholder or a stand-in for a future
component.

Scope and limitations (stated plainly): this detector targets two specific,
well-structured assertion types (allergy status, medication active/
discontinued status) using note templates consistent with the synthetic
corpus. A production system would need a general clinical NLP pipeline
(e.g., a fine-tuned NER + relation-extraction model) to handle free-text
variability well beyond these two patterns.
"""

import re
import json
from pathlib import Path
from collections import defaultdict

DATA_DIR = Path("/home/claude/clinical-rag-contradiction/data")

ALLERGY_PATTERN = re.compile(
    r"Allergies:\s*(No known drug allergies \(NKDA\)\.|Patient reports allergy to ([\w\s]+?)\.)",
    re.IGNORECASE,
)
MED_DISCONTINUED_PATTERN = re.compile(r"Medications:\s*(\w+) discontinued", re.IGNORECASE)
MED_ACTIVE_PATTERN = re.compile(r"Current medications:\s*(.+?)\.", re.IGNORECASE)


def extract_allergy_assertion(note_text: str):
    match = ALLERGY_PATTERN.search(note_text)
    if not match:
        return None
    if match.group(2):
        return match.group(2).strip().lower()
    return "no known drug allergies"


def extract_medication_assertions(note_text: str):
    assertions = {}

    discontinued_match = MED_DISCONTINUED_PATTERN.search(note_text)
    if discontinued_match:
        drug = discontinued_match.group(1).lower()
        assertions[drug] = "discontinued"

    active_match = MED_ACTIVE_PATTERN.search(note_text)
    if active_match:
        med_list_str = active_match.group(1)
        for med_entry in med_list_str.split(";"):
            med_entry = med_entry.strip()
            if med_entry:
                drug_name = med_entry.split()[0].lower()
                assertions.setdefault(drug_name, "active")

    return assertions


def detect_contradictions_for_patient(patient_notes):
    patient_notes = sorted(patient_notes, key=lambda n: n["note_index"])

    allergy_assertions = []
    medication_timeline = defaultdict(list)

    for note in patient_notes:
        allergy = extract_allergy_assertion(note["text"])
        if allergy is not None:
            allergy_assertions.append((note["note_index"], allergy))

        med_assertions = extract_medication_assertions(note["text"])
        for drug, status in med_assertions.items():
            medication_timeline[drug].append((note["note_index"], status))

    flags = []

    distinct_allergy_values = set(v for _, v in allergy_assertions)
    if len(distinct_allergy_values) > 1:
        first_idx, first_val = allergy_assertions[0]
        for idx, val in allergy_assertions[1:]:
            if val != first_val:
                flags.append({
                    "type": "allergy",
                    "note_indices": [first_idx, idx],
                    "description": f"Note {first_idx} states allergy status as '{first_val}'; note {idx} states '{val}'.",
                })
                break

    for drug, timeline in medication_timeline.items():
        timeline_sorted = sorted(timeline, key=lambda t: t[0])
        statuses = [s for _, s in timeline_sorted]
        if "discontinued" in statuses and "active" in statuses:
            disc_idx = next(idx for idx, s in timeline_sorted if s == "discontinued")
            active_after = [idx for idx, s in timeline_sorted if s == "active" and idx > disc_idx]
            if active_after:
                flags.append({
                    "type": "medication",
                    "note_indices": [disc_idx, active_after[0]],
                    "description": f"'{drug}' marked discontinued in note {disc_idx} but listed as active again in note {active_after[0]}.",
                })

    return flags


def run_on_corpus(notes):
    by_patient = defaultdict(list)
    for n in notes:
        by_patient[n["patient_id"]].append(n)

    all_flags = []
    for patient_id, patient_notes in by_patient.items():
        flags = detect_contradictions_for_patient(patient_notes)
        for f in flags:
            f["patient_id"] = patient_id
        all_flags.extend(flags)
    return all_flags


if __name__ == "__main__":
    with open(DATA_DIR / "clinical_notes.json") as f:
        notes = json.load(f)

    flags = run_on_corpus(notes)
    print(f"Detected {len(flags)} contradiction flags across corpus\n")
    for f in flags[:5]:
        print(json.dumps(f, indent=2))
