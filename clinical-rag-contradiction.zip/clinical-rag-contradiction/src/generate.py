"""
Generation layer for the clinical RAG pipeline.

IMPORTANT, stated plainly: this module does NOT call a large language model.
This project's development environment has no network access to any LLM
provider (no API key is available server-side in this sandboxed environment,
and downloading open-weight model files requires access to external model
hubs that are not reachable here). Building this component honestly means
either faking an LLM call or building a real, working, swappable generation
layer without one -- this project does the latter.

`generate_summary()` below produces a structured extractive summary directly
from the retrieved note chunks (no free-text hallucination risk, since every
sentence is copied verbatim from a real retrieved note). This is a legitimate
generation strategy in its own right for a clinical setting, where verbatim
traceability to source notes is often preferred over paraphrase.

To swap in a real LLM (e.g., Claude, GPT-4, or a local Llama model via
Ollama), replace the body of `generate_summary()` with a call such as:

    response = anthropic_client.messages.create(
        model="claude-sonnet-4-5",
        max_tokens=400,
        messages=[{"role": "user", "content": build_prompt(query, retrieved_chunks)}],
    )
    return response.content[0].text

`build_prompt()` below is already written to produce a grounded prompt
(retrieved chunks + instructions to answer ONLY from provided context) that
would work directly with that swap, so the RAG architecture itself does not
change -- only this one function's implementation.
"""


def _strip_punct(word: str) -> str:
    return word.strip(".,?!:;()\"'")


def _normalize(word: str) -> str:
    w = _strip_punct(word)
    # minimal stemming for common clinical query/note mismatches (plural vs singular)
    if w.endswith("ies") and len(w) > 4:
        return w[:-3] + "y"
    if w.endswith("s") and not w.endswith("ss") and len(w) > 3:
        return w[:-1]
    return w


def build_prompt(query: str, retrieved_chunks) -> str:
    context = "\n\n".join(
        f"[Note {c['note']['note_index']}, {c['note']['note_type']}]\n{c['note']['text']}"
        for c in retrieved_chunks
    )
    return (
        "You are a clinical documentation assistant. Answer the question "
        "using ONLY the information in the provided notes. If the notes "
        "contain conflicting information, state the conflict explicitly "
        "rather than picking one version.\n\n"
        f"Notes:\n{context}\n\nQuestion: {query}\n\nAnswer:"
    )


def generate_summary(query: str, retrieved_chunks, contradiction_flags=None) -> str:
    """
    Extractive summary generator (LLM stand-in -- see module docstring).
    Assembles the most relevant retrieved sentences into a structured
    answer, and explicitly surfaces any contradiction flags relevant to
    the retrieved notes rather than silently picking one version.
    """
    if not retrieved_chunks:
        return "No relevant notes found for this query."

    lines = [f'Summary for query: "{query}"\n']

    relevant_note_indices = {c["note"]["note_index"] for c in retrieved_chunks}

    if contradiction_flags:
        applicable_flags = [
            f for f in contradiction_flags
            if set(f["note_indices"]) & relevant_note_indices
        ]
        if applicable_flags:
            lines.append("[!] CONTRADICTION DETECTED in retrieved notes:")
            for f in applicable_flags:
                lines.append(f"  - [{f['type']}] {f['description']}")
            lines.append("")

    lines.append("Retrieved evidence (most relevant notes, verbatim):")
    for c in retrieved_chunks:
        note = c["note"]
        query_terms = set(_normalize(w) for w in query.lower().split())
        note_lines = [l for l in note["text"].split("\n") if l.strip()]
        best_line = max(
            note_lines,
            key=lambda l: len(query_terms & set(_normalize(w) for w in l.lower().split())),
        )
        lines.append(f"  - (Note {note['note_index']}, {note['note_type']}, score={c['score']:.3f}): {best_line.strip()}")

    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    from pathlib import Path
    sys.path.append(str(Path(__file__).parent))
    from retrieval import load_retriever
    from contradiction_detector import run_on_corpus
    import json

    retriever = load_retriever()
    with open(Path(__file__).parent.parent / "data" / "clinical_notes.json") as f:
        notes = json.load(f)
    all_flags = run_on_corpus(notes)

    query = "What are the patient's known drug allergies?"
    patient_id = "PT0000"
    chunks = retriever.retrieve(query, patient_id=patient_id, top_k=4)
    patient_flags = [f for f in all_flags if f["patient_id"] == patient_id]

    summary = generate_summary(query, chunks, patient_flags)
    print(summary)
