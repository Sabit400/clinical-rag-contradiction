"""
Evaluate the rule-based contradiction detector against the ground-truth
contradictions injected by the data generator. Reports precision, recall,
and F1 at the (patient_id, type) level, plus a stricter exact note-index-pair
match for transparency.
"""

import sys
import json
from pathlib import Path

sys.path.append(str(Path(__file__).parent))
from contradiction_detector import run_on_corpus

DATA_DIR = Path("/home/claude/clinical-rag-contradiction/data")
RESULTS_DIR = Path("/home/claude/clinical-rag-contradiction/results")
RESULTS_DIR.mkdir(exist_ok=True)


def evaluate():
    with open(DATA_DIR / "clinical_notes.json") as f:
        notes = json.load(f)
    with open(DATA_DIR / "contradiction_ground_truth.json") as f:
        ground_truth = json.load(f)

    predicted_flags = run_on_corpus(notes)

    gt_set = set((g["patient_id"], g["type"]) for g in ground_truth)
    pred_set = set((f["patient_id"], f["type"]) for f in predicted_flags)

    true_positives = gt_set & pred_set
    false_positives = pred_set - gt_set
    false_negatives = gt_set - pred_set

    precision = len(true_positives) / len(pred_set) if pred_set else 0.0
    recall = len(true_positives) / len(gt_set) if gt_set else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

    gt_exact = set((g["patient_id"], g["type"], tuple(sorted(g["note_indices"]))) for g in ground_truth)
    pred_exact = set((f["patient_id"], f["type"], tuple(sorted(f["note_indices"]))) for f in predicted_flags)
    exact_tp = gt_exact & pred_exact
    exact_precision = len(exact_tp) / len(pred_exact) if pred_exact else 0.0
    exact_recall = len(exact_tp) / len(gt_exact) if gt_exact else 0.0

    results = {
        "n_ground_truth_contradictions": len(gt_set),
        "n_predicted_flags": len(pred_set),
        "true_positives": len(true_positives),
        "false_positives": len(false_positives),
        "false_negatives": len(false_negatives),
        "precision_patient_type_level": round(precision, 4),
        "recall_patient_type_level": round(recall, 4),
        "f1_patient_type_level": round(f1, 4),
        "precision_exact_note_pair": round(exact_precision, 4),
        "recall_exact_note_pair": round(exact_recall, 4),
        "false_positive_examples": [{"patient_id": p, "type": t} for p, t in list(false_positives)[:5]],
        "false_negative_examples": [{"patient_id": p, "type": t} for p, t in list(false_negatives)[:5]],
    }

    with open(RESULTS_DIR / "contradiction_detection_metrics.json", "w") as f:
        json.dump(results, f, indent=2)

    print(json.dumps(results, indent=2))
    return results


if __name__ == "__main__":
    evaluate()
