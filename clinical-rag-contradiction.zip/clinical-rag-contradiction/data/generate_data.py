"""
Synthetic Clinical Notes Corpus Generator
--------------------------------------------
Generates a multi-patient corpus of clinical progress notes with realistic
structure (allergy statements, medication statements, vitals, assessment/
plan), and DELIBERATELY injects a controlled number of contradictions
per patient (e.g., an allergy noted in one note and denied in another;
a medication marked active in one note and discontinued in another) with
ground-truth labels, so the contradiction-detection component can be
evaluated against a known answer key rather than only inspected by eye.

This corpus is entirely SYNTHETIC and FICTIONAL. No real patient data,
real clinical records, or real institution's data is used or represented.
Patient identifiers, names, and note content are generated programmatically.

Author: Sabit Md Asad (project pipeline authored with Claude)
"""

import json
import numpy as np
from pathlib import Path

RANDOM_SEED = 42
N_PATIENTS = 40
NOTES_PER_PATIENT_RANGE = (4, 8)

OUT_DIR = Path("/home/claude/clinical-rag-contradiction/data")

ALLERGENS = ["penicillin", "sulfa drugs", "latex", "shellfish", "no known drug allergies"]
MEDICATIONS = [
    ("Metformin", "500mg", "BID"),
    ("Lisinopril", "10mg", "daily"),
    ("Atorvastatin", "20mg", "nightly"),
    ("Levothyroxine", "75mcg", "daily"),
    ("Albuterol", "90mcg", "PRN"),
    ("Warfarin", "5mg", "daily"),
]
DIAGNOSES = [
    "type 2 diabetes mellitus", "essential hypertension", "hyperlipidemia",
    "hypothyroidism", "asthma", "atrial fibrillation", "chronic kidney disease stage 2",
]
NOTE_TYPES = ["Progress Note", "Admission Note", "Discharge Summary", "Follow-up Visit"]


def make_vitals(rng):
    return {
        "bp": f"{rng.integers(105, 155)}/{rng.integers(65, 95)}",
        "hr": rng.integers(58, 105),
        "temp": round(rng.normal(36.8, 0.3), 1),
        "spo2": rng.integers(94, 100),
    }


def generate_patient_notes(patient_id: str, rng: np.random.Generator):
    n_notes = int(rng.integers(NOTES_PER_PATIENT_RANGE[0], NOTES_PER_PATIENT_RANGE[1], endpoint=True))
    true_allergy = rng.choice(ALLERGENS)
    med_pool = [f"{n} {d} {f}" for n, d, f in MEDICATIONS]
    active_meds = list(rng.choice(med_pool, size=int(rng.integers(1, 3)), replace=False))
    diagnosis = rng.choice(DIAGNOSES)

    inject_allergy_contradiction = rng.random() < 0.35
    inject_medication_contradiction = rng.random() < 0.35

    notes = []
    contradiction_ground_truth = []

    contradicting_allergy = None
    if inject_allergy_contradiction:
        candidates = [a for a in ALLERGENS if a != true_allergy]
        contradicting_allergy = rng.choice(candidates)

    contradicting_med_note_idx = None
    if inject_medication_contradiction and len(active_meds) > 0 and n_notes > 1:
        contradicting_med_note_idx = int(rng.integers(1, n_notes))

    for i in range(n_notes):
        note_type = rng.choice(NOTE_TYPES)
        vitals = make_vitals(rng)

        allergy_stmt_source = contradicting_allergy if (
            inject_allergy_contradiction and i == n_notes - 1
        ) else true_allergy
        allergy_text = (
            "No known drug allergies (NKDA)." if allergy_stmt_source == "no known drug allergies"
            else f"Patient reports allergy to {allergy_stmt_source}."
        )

        if contradicting_med_note_idx is not None and i == contradicting_med_note_idx:
            med_to_discontinue = active_meds[0]
            med_text = f"{med_to_discontinue.split()[0]} discontinued due to adverse effect."
        else:
            med_text = "Current medications: " + "; ".join(active_meds) + "."

        note_text = (
            f"{note_type} — Patient {patient_id}, Visit {i+1}.\n"
            f"Vitals: BP {vitals['bp']}, HR {vitals['hr']}, Temp {vitals['temp']}C, SpO2 {vitals['spo2']}%.\n"
            f"Allergies: {allergy_text}\n"
            f"Medications: {med_text}\n"
            f"Assessment: Patient with history of {diagnosis}, clinically stable at this visit.\n"
            f"Plan: Continue current management, follow up as scheduled."
        )

        notes.append({
            "patient_id": patient_id,
            "note_index": i,
            "note_type": str(note_type),
            "text": note_text,
        })

    if inject_allergy_contradiction:
        contradiction_ground_truth.append({
            "patient_id": patient_id,
            "type": "allergy",
            "description": f"Note 0 states allergy status as '{true_allergy}'; note {n_notes-1} states '{contradicting_allergy}'.",
            "note_indices": [0, n_notes - 1],
        })
    if contradicting_med_note_idx is not None:
        contradiction_ground_truth.append({
            "patient_id": patient_id,
            "type": "medication",
            "description": f"Note 0 lists '{active_meds[0]}' as active; note {contradicting_med_note_idx} states it was discontinued.",
            "note_indices": [0, contradicting_med_note_idx],
        })

    return notes, contradiction_ground_truth


def generate_corpus(n_patients: int = N_PATIENTS, seed: int = RANDOM_SEED):
    rng = np.random.default_rng(seed)
    all_notes = []
    all_ground_truth = []

    for p in range(n_patients):
        patient_id = f"PT{p:04d}"
        notes, ground_truth = generate_patient_notes(patient_id, rng)
        all_notes.extend(notes)
        all_ground_truth.extend(ground_truth)

    OUT_DIR.mkdir(exist_ok=True)
    with open(OUT_DIR / "clinical_notes.json", "w") as f:
        json.dump(all_notes, f, indent=2)
    with open(OUT_DIR / "contradiction_ground_truth.json", "w") as f:
        json.dump(all_ground_truth, f, indent=2)

    print(f"Generated {len(all_notes)} notes across {n_patients} patients")
    print(f"Injected {len(all_ground_truth)} ground-truth contradictions")
    print("Saved to:", OUT_DIR)
    return all_notes, all_ground_truth


if __name__ == "__main__":
    generate_corpus()
